// // import { Account } from "./account";
// import ConnectMetamask from "./walletOptions";

// import DropDown from "./dropDown";
// import { useState } from "react";
// import { Chain } from "@/types";
// import { chains } from "@/const/chain.const";

// export const ConnectWallet = () => {
//   const [network, setNetwork] = useState<Chain>(chains[0]);
//   // if (isConnected) return <Account />;
//   return (
//     <div className="w-[25%] flex gap-3 items-center justify-end">
//       <DropDown setNetwork={setNetwork} network={network} />
//       <ConnectMetamask network={network} />
//     </div>
//   );
// };


import React from 'react';

const ConnectButton = () => {
  return (
    <div>
      <w3m-button />
    </div>
  );
};

export default ConnectButton;