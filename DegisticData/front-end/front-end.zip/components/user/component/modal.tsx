import { Button } from "@nextui-org/button";
import {
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  useDisclosure,
} from "@nextui-org/modal";
import { useState } from "react";
import { Form } from "@nextui-org/form";
import { Input } from "@chakra-ui/input";
import { Select, SelectItem } from "@nextui-org/select";
import { useAccount, useReadContract } from "wagmi";
import { DeliveryAbis } from "@/config/abis/delivery";
import { ethers } from "ethers";
import { SubmitButton } from "./SubmitButton";
import { CreateOrder } from "@/types";

export default function OrderModal() {
  const { isOpen, onOpen, onOpenChange } = useDisclosure();
  const [action, setAction] = useState<string>("");
  const [name, setName] = useState<any>("");
  const [receiver, setReceiver] = useState<string>("");
  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");
  const account = useAccount();

  const list = useReadContract({
    chainId: 420420421,
    address: `0x${process.env.NEXT_PUBLIC_DELIVERY_SMART_CONTRACT_ADDRESS}`,
    functionName: "getAllStation",
    abi: DeliveryAbis,
  });

  const abiCoder = new ethers.AbiCoder();
  const _stations =
    Array.isArray(list.data) && list.data.length > 0
      ? list.data.map((item: any) => ({
          id: item.station_id,
          validators: item.validators,
          name: abiCoder.decode(["string"], item.name).toString(),
        }))
      : [];

  const params: CreateOrder = {
    _station_ids: [from, to],
    _name: name,
    _sender: `0x${account.address?.substring(2)}`,
    _receiver: receiver,
  };

  return (
    <>
      <Button onPress={onOpen}>Add order</Button>
      <Modal
        isDismissable={false}
        isKeyboardDismissDisabled={true}
        isOpen={isOpen}
        onOpenChange={onOpenChange}
      >
        <ModalContent>
          {(onClose) => (
            <>
              <ModalHeader className="flex flex-col gap-1">
                New order
              </ModalHeader>
              <ModalBody>
                <Form
                  className="w-full max-w-xs flex flex-col gap-4"
                  validationBehavior="native"
                  onReset={() => setAction("reset")}
                  onSubmit={(e) => {
                    e.preventDefault();
                    let data = Object.fromEntries(
                      new FormData(e.currentTarget)
                    );

                    setAction(`submit ${JSON.stringify(data)}`);
                  }}
                >
                  <span>Name</span>
                  <Input
                    isRequired
                    className="max-w-xs"
                    defaultValue="junior"
                    type="text"
                    onChange={(e) => setName(e.target.value)}
                  />
                  <span>Receiver address</span>
                  <Input
                    isRequired
                    className="max-w-xs"
                    defaultValue="0x0"
                    type="text"
                    onChange={(e) => setReceiver(e.target.value)}
                  />
                  <span>From</span>
                  <Select className="max-w-xs" label="Select send station">
                    {_stations.map((item: any) => (
                      <SelectItem onPress={() => setFrom(item.id)}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </Select>
                  <span>To</span>
                  <Select className="max-w-xs" label="Select receive station">
                    {_stations.map((item: any) => (
                      <SelectItem onPress={() => setTo(item.id)}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </Select>
                </Form>
              </ModalBody>
              <ModalFooter>
                <Button color="danger" variant="light" onPress={onClose}>
                  Close
                </Button>
                <SubmitButton onClose={onClose} data={params} />
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </>
  );
}
