import { Button } from "@nextui-org/button";
import { createOrder } from "@/context/delivery";
import { ethers } from "ethers";
import { useWriteContract } from "wagmi";
import { CreateOrder } from "@/types";
import { DeliveryAbis } from "@/config/abis/delivery";
import { DeliveryWriteFunc } from "@/const/common.const";
import { stringToBytes, toBytes } from "viem";

export const SubmitButton = ({
  onClose,
  data,
}: {
  onClose: () => void;
  data: CreateOrder;
}) => {
  const { writeContractAsync } = useWriteContract();
  const abiCoder = new ethers.AbiCoder();
  const createOrder = async () => {
    const { _station_ids, _name, _sender, _receiver } = data;

    const a = stringToBytes(_name)
    const execute = await writeContractAsync({
      abi: DeliveryAbis,
      address: `0x${process.env.NEXT_PUBLIC_DELIVERY_SMART_CONTRACT_ADDRESS}`,
      functionName: DeliveryWriteFunc.CREATEORDER,
      args: [
        _station_ids.map((id) => abiCoder.encode(["bytes32"], [id])),
        _name,
        `0x${_sender.substring(2)}`,
        `0x${_receiver.substring(2)}`,
      ],
    });

    // onClose();
  };
  return (
    <Button color="primary" onPress={createOrder}>
      Submit
    </Button>
  );
};
